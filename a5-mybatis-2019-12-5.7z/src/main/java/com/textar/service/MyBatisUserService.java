package com.textar.service;

import com.textar.pojo.User;

public interface MyBatisUserService {
	public User getUser(Long id);

}
